package com.example.sidemanagementbe.chat.dto;

import com.example.sidemanagementbe.chat.entity.Chat;
import lombok.Builder;
import lombok.Getter;

import java.time.LocalDateTime;

@Builder
@Getter
public class ChatDto {
    private Long teamId;
    private Long memberId;
    private String content;
    private LocalDateTime createdDateTime;
    private LocalDateTime modifiedDateTime;

//    public static ChatDto entityToDto(Chat chat){
//        return ChatDto.builder()
//                .teamId(chat.getChatId())
//                .memberId(chat.getMemberId())
//                .content(chat.getContent())
//                .build();
//    }
}
