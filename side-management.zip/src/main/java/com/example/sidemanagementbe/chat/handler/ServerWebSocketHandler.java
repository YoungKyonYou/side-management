//package com.example.sidemanagementbe.chat.handler;
//
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import org.springframework.web.socket.TextMessage;
//import org.springframework.web.socket.WebSocketSession;
//import org.springframework.web.socket.handler.TextWebSocketHandler;
//import org.springframework.web.util.HtmlUtils;
//
//import java.io.IOException;
//import java.time.LocalTime;
//
//@Slf4j
//@Component
//public class ServerWebSocketHandler extends TextWebSocketHandler {
//    @Override
//    public void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
//        String request = message.getPayload();
//        log.info("Server received: {}", request);
//
//        String response = String.format("response from server to '%s'", HtmlUtils.htmlEscape(request));
//        log.info("Server sends: {}", response);
//        session.sendMessage(new TextMessage(response));
//    }
//
//   // private WebSocketController webSocketController;
////    private static final Map<String, Set<WebSocketSession>> roomSessions = new ConcurrentHashMap<>();
////
////    @Override
////    public void afterConnectionEstablished(org.springframework.web.socket.WebSocketSession session) throws Exception {
////        log.info("-------Connection Established---------");
////        String roomId = extractRoomIdFromSession(session);
////        Set<WebSocketSession> sessions = roomSessions.computeIfAbsent(roomId, key -> ConcurrentHashMap.newKeySet());
////        sessions.add(session);
////    }
////    @Override
////    public void afterConnectionClosed(org.springframework.web.socket.WebSocketSession session, CloseStatus status) throws Exception {
////        log.info("-------Connection Closed---------");
////        String roomId = extractRoomIdFromSession(session);
////        Set<WebSocketSession> sessions = roomSessions.getOrDefault(roomId, Collections.emptySet());
////        sessions.remove(session);
////    }
////
////    @Override
////    protected void handleTextMessage(org.springframework.web.socket.WebSocketSession session, TextMessage message) throws Exception {
////        String roomId = extractRoomIdFromSession(session);
////        Set<WebSocketSession> sessions = roomSessions.getOrDefault(roomId, Collections.emptySet());
////        for (WebSocketSession s : sessions) {
////            s.sendMessage(message);
////        }
////    }
////
////
////    private String extractRoomIdFromSession(WebSocketSession session) {
////        // 대화방 ID를 세션에서 추출하는 로직 구현
////        // 예시로는 세션의 URI에서 roomId 파라미터를 추출하도록 작성하였습니다.
////        UriComponents uriComponents = UriComponentsBuilder.fromUri(session.getUri()).build();
////        String roomId = uriComponents.getQueryParams().getFirst("roomId");
////        if (roomId == null || roomId.isEmpty()) {
////            throw new IllegalArgumentException("Invalid roomId");
////        }
////        return roomId;
////    }
//
//}