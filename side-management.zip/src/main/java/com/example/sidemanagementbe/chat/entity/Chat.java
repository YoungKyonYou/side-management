package com.example.sidemanagementbe.chat.entity;


import com.example.sidemanagementbe.chat.dto.ChatDto;
import com.example.sidemanagementbe.common.entity.BaseEntity;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;


@Builder
@AllArgsConstructor(access = AccessLevel.PROTECTED)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Getter
@Entity
@PrimaryKeyJoinColumn(name = "team_id")
@Table(name = "saida_chat")
public class Chat extends BaseEntity{

    @Column(nullable = false)
    private Long member;

    private String content;

//    public static Chat dtoToEntity(ChatDto chatDto){
//        return Chat.builder()
//                .chatId(chatDto.getTeamId())
//
//                .content(chatDto.getContent())
//                .build();
//    }

    // Getter, Setter, 생성자, 기타 메소드
}
