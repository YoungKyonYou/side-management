//package com.example.sidemanagementbe.chat.interceptor;
//
//import com.example.sidemanagementbe.web.security.util.JwtTokenProvider;
//import lombok.AllArgsConstructor;
//import lombok.RequiredArgsConstructor;
//import lombok.SneakyThrows;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.messaging.Message;
//import org.springframework.messaging.MessageChannel;
//import org.springframework.messaging.simp.stomp.StompCommand;
//import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
//import org.springframework.messaging.support.ChannelInterceptor;
//import org.springframework.messaging.support.MessageHeaderAccessor;
//
//import javax.security.auth.message.AuthException;
//
//
//@Configuration
//@RequiredArgsConstructor
//@Slf4j
//public class WebSocketInterceptor implements ChannelInterceptor {
//    private final JwtTokenProvider jwtProvider;
//
//    @SneakyThrows
//    @Override
//    public Message<?> preSend(Message<?> message, MessageChannel channel) {
//        log.info("-------preSend-----------");
//        StompHeaderAccessor accessor = MessageHeaderAccessor.getAccessor(message, StompHeaderAccessor.class);
//
//        if (accessor.getCommand() == StompCommand.CONNECT) {
//            String authToken = accessor.getFirstNativeHeader("Authorization");
//
//            if (authToken == null || !jwtProvider.validateToken(authToken)) {
//                throw new AuthException("Authentication failed!!");
//            }
//        }
//        return message;
//    }
//}
