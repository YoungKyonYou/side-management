package com.example.sidemanagementbe.chat.service;

import com.example.sidemanagementbe.chat.dto.ChatDto;
import com.example.sidemanagementbe.chat.entity.Chat;
import com.example.sidemanagementbe.chat.repository.ChatRepository;
import com.github.dockerjava.api.exception.NotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import java.util.Optional;

@AllArgsConstructor
@Service
public class ChatService {

//    private final ChatRepository chatRepository;
//
//    public ChatDto getContentByTeamId(Long teamId){
//        Optional<Chat> chat = chatRepository.findById(teamId);
//
//        if(!chat.isPresent()){
//            throw new NotFoundException("Chat not found for team ID: " + teamId);
//        }
//
//        Chat chatResult = chat.get();
//
//        ChatDto chatDto = ChatDto.entityToDto(chatResult);
//
//        return chatDto;
//    }
//
//    public ChatDto saveMessage(ChatDto chatDto){
//        Chat chat = Chat.dtoToEntity(chatDto);
//        Chat saveChat = chatRepository.save(chat);
//        return ChatDto.entityToDto(saveChat);
//    }
}
