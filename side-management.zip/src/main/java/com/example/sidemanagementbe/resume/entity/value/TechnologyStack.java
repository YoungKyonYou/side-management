package com.example.sidemanagementbe.resume.entity.value;

import lombok.Getter;

@Getter
public enum TechnologyStack {
    JAVA,
    SPRING,
    JAVASCRIPT,
    REACT
}
