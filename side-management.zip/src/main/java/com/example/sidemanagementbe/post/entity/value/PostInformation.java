package com.example.sidemanagementbe.post.entity.value;


import javax.persistence.Embeddable;

@Embeddable
public class PostInformation {
    private Title title;
    private Content content;
}
