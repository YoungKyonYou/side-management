package com.example.sidemanagementbe.login.entity;

public enum Gender {
    MAN, WOMAN
}
