package com.example.sidemanagementbe.login.entity;

public class Address {
}
