package com.example.sidemanagementbe.login.entity;

public enum MemberRole {
    USER, MANAGER, ADMIN
}
